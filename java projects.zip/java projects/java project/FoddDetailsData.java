import javax.swing.*;

public class FoddDetailsData extends JFrame  
{  
    FoddDetailsData()  
    {  
        setDefaultCloseOperation(javax.swing.  
        WindowConstants.DISPOSE_ON_CLOSE);  
        setTitle("Food Details");  
        setSize(600, 400);  
    }  
} 